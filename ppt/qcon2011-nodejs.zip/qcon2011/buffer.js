var a = new Buffer(10);
console.log(a, a.toString());
var b = new Buffer('QCon2011杭州');
console.log(b, b.toString());